# ViralOS Autonomous Coding Agent — Deterministic Build Runbook

**Instruction:** Implement **Launch first**, then Ultimate in additive milestones. This is a controlled build contract, not permission to invent external credentials, data or media rights. Never submit “Done” without test evidence.

## A. Initialization checklist

1. Read `README_START_HERE.md`, `SPEC_AUTHORITY_AND_AGENT_RULES.md`, selected project plan and all shared core specs.
2. Run `python tools/validate_spec.py` and capture output. This validates the documentation package **only**.
3. Inspect any existing ViralOS source ZIP/repo passed by owner; produce a `repo_inventory.json` with files/tests/architectural deviations and specific reuse decisions. Do **not** assume earlier starter ZIP implements stated features.
4. Verify Windows environment, CPU/RAM/disk, Python, FFmpeg, local font/voices and optional model availability. Display exact unavailable dependencies; don't download large models without consent.
5. Create `implementation_status.csv` from `tests/REQUIREMENTS.csv` with statuses `NOT_STARTED, IN_PROGRESS, IMPLEMENTED, TESTED, VERIFIED, BLOCKED` and evidentiary paths. Never mark features verified preemptively.
6. Check official API/YPP/reused-content/synthetic-media policies and provider terms when integrations begin. Record `checked_at, URL, applicable limits, decision`. No fake rates or API access.

## B. Build tasks and dependencies

| Build ID | Dependencies | Required implementation output | Exit evidence |
|---|---|---|---|
| B-001 Repository scaffold | None | Python/FastAPI/React, lint/typecheck/tests/lockfiles, Windows scripts | Health endpoint on no-GPU PC |
| B-002 Durable DB | B-001 | Alembic migrations from `database/schema.sql`, FK/FTS/WAL, backups | Schema install, migration/restore tests |
| B-003 API/data contracts | B-001/B-002 | Pydantic models mirroring contracts, strict validation, error envelope | Contract compatibility tests |
| B-004 Jobs/capabilities | B-002/B-003 | Durable job scheduler, workers, cancellation, retries, 4 modes | State machine/CPU-only tests |
| B-005 Channels and secrets | B-003 | Channel CRUD, locale/market/brand/risk, DPAPI-backed token refs | Cross-channel/secret tests |
| B-006 Safe connectors | B-003/B-004 | Manual URL, permitted RSS and verified sport provider adapters; metadata/quota | Source freshness and SSRF tests |
| B-007 Trend engine | B-006 | Observations, dedupe, historical series, coverage gaps, explanation | Missing-provider and duplicate fixtures |
| B-008 Evidence graph | B-002/B-006 | SourceVersions, claim extraction, citations and independence, review flags | False-citation and copied-report fixtures |
| B-009 Domain sports | B-007/B-008 | Cricket/NFL ontology/calculators, field diagrams, source-specific stats | Base-six and NFL fixture goldens |
| B-010 Tech optional pilot | B-008 | Reproducible demo/test adapter, no untested claims | Actual command/run log vs vendor claim test |
| B-011 Creative script/plan | B-009/B-008 | Original narrative, source spans, SceneSpec, rights manifest | Claim/screenplay mapping tests |
| B-012 CPU media | B-011/B-004 | TTS/manual voice, charts, captions, FFmpeg, two profiles | Original playable Short + long export |
| B-013 Editorial and rights | B-008/B-011/B-012 | Hard gate, reports, signed human approval snapshots, invalidation | Reused clip/edited script tests |
| B-014 Publishing/export | B-013/B-005 | Offline export, OAuth authorized provider adapter, reconciliation | Manual export, mock API tests; live only if authorized |
| B-015 Analytics/learning | B-014 | Observed authorized Analytics, cohorts, experiments and audit | Metric availability/fixture isolation tests |
| B-016 Revenue/GPU fund | B-015 | Actual/estimated ledger separation and quote-based savings | Decimal precision/revenue evidence tests |
| B-017 Operator UI/ops | B-001..B-016 | Screens, logs, backups, recovery, missing-source states | Full operator E2E on Windows |
| B-018 Launch release | B-001..B-017 | Signed/checksummed release package, reports, runbook | All nondeferred L-* requirements VERIFIED |
| B-019 Ultimate trust domains | B-018 | Newsroom/Science and remaining domain dossiers with real tools | Domain goldens and genuine source-case work |
| B-020 Ultimate AI media | B-018 | Model registry, ComfyUI adapters, CPIE and continuity on actual GPU | Model license, resource and temporal QC tests |
| B-021 Ultimate distributed | B-020 | Secure multi-GPU/remote capability, artifacts and worker leases | Real multiworker recovery tests |
| B-022 Optional SaaS | Owner ADR after B-018 | Tenant isolation/postgres/billing only if explicitly approved | Separate security/privacy audit |

## C. Development discipline

- One code owner for each core service, no second `research.py` in each domain to override evidence behavior. Domain manifests register adapters with common plugin protocol.
- Commit schema/contract changes with migration and regression tests in same unit of work.
- Implement real backend actions before presenting UI button as active. Unimplemented buttons must be disabled with actual reason.
- Source and content prompts use JSON/Pydantic validation; retry invalid model output boundedly, then `BLOCKED_INVALID_MODEL_OUTPUT`, not ad hoc regex assumption.
- Every fetch/playback/video process includes timeout, size, license, quota and safe path guard.
- Never silently replace missing data with a convenient story. If missing, complete draft only when risk acceptable and gap is disclosed.
- Publish only after verifying exact approved revision, channel, intended privacy, rights, disclosure and authorization. Default manual.
- Security and provenance are **infrastructure**, not backlog polish.

## D. Agents that work in parallel

Only parallelize work with stable contracts and directory ownership. Suggested lanes: `backend/core+db`, `frontend`, `domain_sports+fixtures`, `media/ffmpeg`, `official integrations`, `quality/tests`. Central agent owns API/schema changes and merge decisions. Two agents must not concurrently edit DB schema or generic evidence/publishing service. Merge requires contract tests and reviewer.

## E. Handoff report per milestone

```
Milestone ID:
Requirements implemented (exact IDs):
Files changed:
New/changed schema versions:
Non-placeholder endpoints/screens:
Unit / integration / E2E test command + result:
Windows CPU-only measured evidence:
Rights/source sample evidence:
Known blockers and next safe steps:
External accounts/actions performed with owner consent:
Old project compatibility and backup outcome:
```

If a required test cannot be run, label `BLOCKED_EXTERNAL`/`NOT_VERIFIED`; never claim full completion. Do not install SaaS, pay APIs, leak private docs, publish allegations or launch GPU inferencing without consent and compatible hardware.

## F. Acceptance owner walkthrough (Launch)

A clean Windows boot -> create India cricket and US NFL profiles (no OAuth necessary) -> ingest at least one authentic permitted source for an actual prior match and a manually supplied research question -> view original links and source versions -> obtain factual citation report -> draft original 45–90 second Short and one longer tutorial/analysis -> inspect unique field diagrams -> import licensed/original assets -> render on CPU -> watch output -> approve/reject -> export complete bundle -> restart app and recover project/job -> view correct analytics unavailable state -> record optional actual earning/expense -> backup and restore to new workspace. This real walkthrough is essential even if AI unit tests all pass.

## G. Owner decisions and safe defaults

See `configs/decision_register.json`. Agent needn't ask owner all questions at once. Where missing source/broadcaster rights or real account, preserve useful offline path and record exact blocker; do not invent new services. On GPU absence, do not replace AI-video request with unexplained slideshow; propose approved CPU alternate.
