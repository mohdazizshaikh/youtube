# Source Blueprints Review, Reconciliation and Gap Register

**Inputs inspected:** `source_snapshots/Launch_v1_1_ORIGINAL.md` (232 lines, 22,934 bytes) and `source_snapshots/Ultimate_v1_1_ORIGINAL.md` (366 lines, 39,445 bytes). These files came from prior project discussion; retained byte-for-byte. This document reviews **specification completeness**, not runtime correctness.

## Major defects of v1.1 and resolution in v2.0

| Defect | Risk for autonomous coding | Normative resolution | Status |
|---|---|---|---|
| Launch/Ultimate overlap and scattered addenda | Two different versions of shared logic | One codebase, fixed authority order, one domain registry | SPECIFIED |
| Engine names without algorithm and I/O | Model invents workflow | `core/04–08` + each `domains/` file define preconditions, steps, outputs, errors and tests | SPECIFIED |
| Schema described as bare table names | FK, enum, migration conflicts | `database/schema.sql`, JSON contracts, migration discipline | SPECIFIED |
| No consistent approval semantics | Unintended public upload | `core/03`, `core/09`, rule-based gating and signed approval snapshots | SPECIFIED |
| No confidence/independence definition | Multiple copied news articles counted as proof | `core/05` source family, provenance, evidence admissibility and completeness scoring | SPECIFIED |
| “All trends” requirement not bounded | Invented 100% internet coverage | Provider coverage and quota ledger with explicit gaps, no circumvention | SPECIFIED |
| Cricket/NFL not deeply distinguished | Generic scripts and wrong sports metrics | `domains/sports.md` sub-adapters + fixtures and versioned rules | SPECIFIED |
| 12 domains described as headings | Shallow generic prompt hacks | 12 detailed mandatory domain dossiers and tests | SPECIFIED |
| GPU toggle undefined implementation | Decorative GUI, errors after upgrade | Capability manifests, compatibility and reservations in `core/08` | SPECIFIED |
| “Deep prompt engine” without reproducibility | Inconsistent shots and wasted compute | `core/07` typed SceneSpec, shot compiler, asset and generation provenance | SPECIFIED |
| YouTube analytics/revenue conflated | Fake profitability dashboards | `core/09`, authorized metrics, observed/predicted separation, ledger | SPECIFIED |
| No actual data connector/legal terms inventory | Fake API endpoints or unlawful scraping | Connector contract, source catalog, verified references and `BLOCKED` states | SPECIFIED |
| No acceptance-to-requirement mapping | Agent declares success after stub | Tests registry, validation and traceability | SPECIFIED |
| No offline/resume/error story | Lost renders or partial upload duplicates | Durable workflows, idempotency, reconciliation, backup and fault tests | SPECIFIED |
| Public allegations/AI reconstructions | Defamation, misinformation, misleading footage | Rights and risk gates; reconstruction disclosure | SPECIFIED |
| No cost/compute feasibility budget | CPU 32GB cannot run all tasks | Capability-based scheduler; sequential heavy jobs; unsupported jobs held | SPECIFIED |
| No channel-level dedup/cannibalization | Duplicate publishing and repetitive content | Content fingerprints, similarity audits, portfolio policies | SPECIFIED |
| Future SaaS mixed into MVP | Scope creep and security shortcuts | Ultimate-only optional phase; tenancy only after owner validation | SPECIFIED |

## Explicitly unresolved / externally constrained items

These are **not omissions to fill by hallucination**. They are blocked input categories with fallback behaviors.

| ID | Unresolved or external input | Safe default / agent behavior | Evidence needed |
|---|---|---|---|
| D-001 | YouTube channel IDs, API credentials, OAuth consent | Manual export; YouTube integration disabled | Authorized owner credentials |
| D-002 | Broadcaster/sports clip licenses | Do not use protected game footage; use self-created graphics and licensed alternatives | Written rights/eligible legal review |
| D-003 | Paid proprietary stats, social APIs, Google Trends access | Connector stays disabled, surface source coverage gap | Provider agreement/API capability |
| D-004 | Specific local LLM/video generator model | Choose from locally benchmarked, license-checked compatible manifest; otherwise template/manual pathway | Model provenance/benchmark |
| D-005 | Exact i7 CPU SKU, SSD/storage, OS build, network capacity | Conservative sequential CPU; show preflight blocker if disk/instructions insufficient | Hardware detector output |
| D-006 | Narrator identity, voice cloning rights, language details | Licensed local non-impersonating default TTS; user can change | Preference and voice license |
| D-007 | Accepted publishing cadence / total editorial hours | No forced publishing cadence; recommendations only | Owner review |
| D-008 | A6000 supplier quote/price, power/cooling | GPU savings target is owner-entered, no invented price | Current quotation |
| D-009 | SaaS tenant/billing/data jurisdiction | No SaaS deployment in Launch; feature flag off | Later owner/business decisions |
| D-010 | Current YPP/API/legal terms after snapshot | Compliance refresh before integration and periodically | Official live documentation |
| D-011 | Source language coverage and translation accuracy | Preserve original and translation; disputed quote requires review | Source text/human reviewer |
| D-012 | Real audience/revenue performance | Show no metrics until authorized observed imports | YouTube Analytics/Studio/account data |

## Historical continuity guarantee

The old v1.1 documents and the preceding conversation identified: local-first ownership; 12 category specialist OS; research depth; political/history/finance/media evidence; speech contradiction protocol; trend coverage; audience psychology; Shorts/long-form; sports markets; copyright/originality; human oversight; creator production; prompt engineering; CPU/GPU toggle; image/video generation; YouTube first revenue and GPU savings; backup/security; future SaaS. All map to a home in this package. This is a **scope mapping**, not proof no topic was ever omitted.

## Change history

- **v1.1 2026-11-09:** Prior authoring, conceptual blueprints and appendices (frozen in `source_snapshots`).
- **v2.0 2026-11-09:** Unified authority, explicit release profiles, domain dossiers, canonical contracts, SQLite baseline, lifecycle/state rules, test registry, bounded automation, GPU and rights policy.
