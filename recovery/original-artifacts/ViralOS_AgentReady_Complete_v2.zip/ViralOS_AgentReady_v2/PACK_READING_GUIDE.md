# How to Use This Pack with Any Coding Agent

**Best option:** upload or extract the full `ViralOS_AgentReady_Complete_v2.zip` and give the agent `AGENT_BOOTSTRAP_PROMPT.md`. For agents with limited context, do not stuff all 12 domain dossiers into one prompt. Follow the read order and implement one milestone at a time, verifying every source and contract. The two large standalone Markdown files are convenience snapshots, not permission to skip implementation tests.

**If you only give one file:** use `standalone/ViralOS_Launch_Standalone_v2.md` to build Launch, or `standalone/ViralOS_Ultimate_Standalone_v2.md` to understand the entire long-term product. Each contains shared core specs, machines schemas, SQL and test registries, with original canonical path markers. Ultimate also includes Launch and all 12 domains. Smaller agents may need to split these by `BEGIN CANONICAL FILE` markers.

**Practical agent instruction:** First implement `B-001` through `B-004` and provide real source/tests, then resume through the Launch runbook; do not attempt to produce the full product in one giant untested answer. Recheck official YouTube/source provider terms at implementation. Every unverified credential, footage right, exact model compatibility or owner setting must remain a visible blocker, not a guessed fact.

**What is complete now:** The product specification, canonical ownership and test plan **as far as can be reasonably defined without actual source access, hardware benchmarks and owner decisions**. **What is not complete:** the software, real API bindings, production videos, YPP eligibility, GPU model tests or verified financial income.
