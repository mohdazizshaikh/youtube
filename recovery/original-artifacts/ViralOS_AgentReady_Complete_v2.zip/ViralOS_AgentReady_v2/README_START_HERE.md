# ViralOS Agent-Ready Specification Pack — v2.0

**Type:** ENGINEERING SPECIFICATION PACKAGE, **not** working software, not certified complete or error-free.
**Product:** local-first YouTube creator intelligence, research, production and publishing platform.
**Date:** 2026-11-09. **Audience:** implementing AI coding agents, human developers, testers, product owner.

## What to build

Build **one codebase** with two release profiles, **Launch** and **Ultimate**. They are not two divergent applications. Launch is the first executable vertical slice, Ultimate is a future complete feature superset. Do not delete advanced requirements merely because they are not in Launch. Both editions share the same durable identities, contracts, database migrations, worker design, provenance and safety gates.

- `projects/LAUNCH_EXECUTION_SPEC.md`: current owner-only, YouTube-first initial scope; must run on Windows PC with Intel i7 8th-generation CPU, 32 GB RAM and **no discrete GPU**. Start with no more than 2 active pilot channels. Initial hypotheses: India cricket (Hindi/Hinglish) and US NFL (English); Tech as fallback/control; MLB/NBA are backlog; user may change channel choices. Revenue target is **only own YouTube channels**, saved toward compatible future GPU; no initial client sales.
- `projects/ULTIMATE_EXECUTION_SPEC.md`: long-term all 12 domain operating systems, generative studio, full evidence network, cross-domain routing, optional SaaS. Capabilities are not considered working until tested.
- `core/`: canonical behavior. This folder is the **only owner** of shared algorithms.
- `domains/`: exactly 12 separately defined domain engines. `sports` owns cricket/NFL/MLB and other sports as adapters; they are **not extra top-level domains**.
- `contracts/`: machine-readable data structures; contracts are authoritative over prose field examples.
- `database/`: baseline SQLite schema used by Launch and extended via migrations for Ultimate; it is not permission to reset data.
- `configs/`: canonical registries and default policies. User overrides must be explicit and logged.
- `tests/`: acceptance matrix and example fixtures/validation, not evidence that the application has passed tests.
- `source_snapshots/`: exact old v1.1 docs for historical comparison only; **superseded**, never independently implement from these if newer authority conflicts.

## Read order for an implementing agent

1. `SPEC_AUTHORITY_AND_AGENT_RULES.md` (non-negotiable constraints, conflict resolution, anti-hallucination contract).
2. `AUDIT_AND_CHANGELOG.md` (what was missing and how it is now addressed).
3. `projects/LAUNCH_EXECUTION_SPEC.md` **or** `projects/ULTIMATE_EXECUTION_SPEC.md`, depending on assignment.
4. all numbered `core/00_*.md` through `core/13_*.md` in numeric order.
5. Relevant `domains/*.md` and `configs/domain_registry.json`.
6. `contracts/*.schema.json`, `database/schema.sql`, `tests/ACCEPTANCE_MATRIX.csv`.
7. Run `python tools/validate_spec.py` from pack root. Validator checks internal package consistency; it **does not** test or build ViralOS.

## Explicit document hierarchy (highest to lowest)

1. Hard platform safety, law, API Terms of Service, copyright/rights restrictions; never override them by internal spec.
2. `SPEC_AUTHORITY_AND_AGENT_RULES.md`.
3. Machine-readable `contracts/*.schema.json`, `configs/*.json`, `database/schema.sql`, and `tests/REQUIREMENTS.csv` for field names, enum values and unique IDs.
4. `core/*.md` for shared behavior and common algorithms.
5. `domains/*.md` for domain-specific specialization (may tighten, never weaken shared safety).
6. Edition release plans for activation sequence.
7. Older v1.1 snapshots for background; non-normative.

When real APIs, licenses, model availability or software versions differ from this 2026-11-09 snapshot, **verify current official documentation and create a tracked change proposal**; do not silently replace specified behavior.

## Definition of an agent handoff

The agent must leave (a) runnable source; (b) frozen dependency lockfiles; (c) schema migrations; (d) unit/integration/E2E suites; (e) CPU-only Windows installation and recovery instructions; (f) example research with actual cited source hashes; (g) a real original exported Short and long video; (h) policy/rights manifests; (i) a traceability report; (j) an honest list of blocked/untested items. No GUI button counts as implemented unless it performs its advertised action. No example fixture may be presented as observed production analytics.

**Not included:** YouTube credentials, proprietary source subscriptions, broadcaster footage rights, actual niche market guarantees, guaranteed income, verified Windows performance benchmarks, local GPU hardware, or working 12-domain application. These cannot be invented from prose.
