# ViralOS Specification Authority / AI-Agent Operating Contract

**Applies to every implementing agent, subcontracted assistant, test runner, and code generator.** All SHALL/MUST/NEVER statements are normative. This document has precedence over conflicting feature prose.

## A. Scope invariants

1. Deliver **one product**, one database migration lineage, one shared evidence/identity system and **one** pluggable creator pipeline. Release profile controls features; avoid parallel incompatible Launch/Ultimate codebases.
2. Owner first: create videos for user's **own YouTube channels**; do not build B2B sales, freelance services, lead-generation, customer billing, or SaaS monetization in Launch.
3. Baseline: Windows 10/11 x64, Intel Core i7 8th gen, 32 GB RAM, no dedicated GPU; zero recurring spend is a **constraint**, not a guarantee of all free data availability. Operate CPU-first. GPU/remote expansion must not change content project or source IDs.
4. Exactly twelve `domain_id`: `newsroom, science, technology, business, gaming, history, space, learning, sports, career, productivity, culture`. Cricket/NFL/MLB are sports adapters `sport_id`, not thirteenth domains.
5. Default language/market for initial pilot hypotheses: India cricket Hindi/Hinglish (`hi-IN` with per-asset language markers) and US NFL English (`en-US`). They are configuration defaults, not factual audience claims or locked owner decisions.
6. Do not assume growth, subscribers, monetization, impressions, revenue, free API coverage, copyright clearance, YouTube upload approval, AI model availability, or GPU procurement.
7. Avoid copied/reuploaded clips with cosmetic changes and repetitive low-value templated output; meaningful original contribution and asset rights are separate mandatory checks.

## B. Agent behavior policy

- **NO INVENTED FACTS:** Never create fabricated sources, quotes, full speeches, sports scores, statistics, ownership links, scientific conclusions, GPU benchmarks, API responses, public opinions, retention data, prices or profit. Mock fixtures MUST be visibly `synthetic_test_fixture=true` and excluded from operational dashboards.
- **NO SILENT SUBSTITUTIONS:** Do not swap API providers, add external paid services, change default publishing to public, or relax safety gates when an integration fails. Return `BLOCKED_*` reason and a review task.
- **NO AUTONOMOUS SCOPE EXPANSION:** Implement only registered requirement IDs. Necessary infrastructure can be added if referenced by an ID or documented design record; proposals for unrelated features remain `PROPOSED`, not implemented.
- **NO DUPLICATE OWNERS:** A canonical `owner_module` owns each persisted entity and shared algorithm. Domain plugins contribute configurations/adapters, not their own duplicate source registries, analytics facts, policy gates or upload clients.
- **NO INFERRED USER APPROVAL:** Uploading, scheduled public publishing, rights clearance, allegation publication, model download/license acceptance, account connection, GPU installation and third-party spending need actual user authorization. Approval tokens expire on material edits.
- **NO CLAIMS OF PERFECT AUTOMATION:** Automation may stop for uncertain evidence, unavailable data, legal risks, human judgment or credentials. Every automation job can be reviewed, canceled and resumed.
- **NO POLITICAL POSITION ASSUMPTIONS:** Apply identical evidence standards to public claims by different political actors. Scrutinize source quality; do not preordain guilt, conspiracy, or conclusions. No false equivalence when evidence strength differs.
- **NO EVALUATION BY VIEWS ALONE:** Actual YouTube analytics and earnings remain separate from opportunity estimates, fake dashboards and synthetic examples.

## C. Ambiguity-resolution protocol

For each missing parameter, use the following precedence:
1. Explicit owner-provided setting saved in a versioned profile; validate type/range.
2. Normative contract and default policy from this package.
3. Provider metadata discovered through a permitted, documented integration.
4. If still ambiguous: mark `NEEDS_OWNER_DECISION` or `NEEDS_EXTERNAL_VERIFICATION` with exact missing field, reason, impacted job and safe next action. **Never guess**.

`NEEDS_OWNER_DECISION` does not mean ask every question up front. Build the independently executable safe portions and expose blockers in the dashboard. User can review a structured decision queue later.

## D. Mandatory acceptance protocol

- A task is `SPECIFIED` only with ID, owning module, interfaces, invariants, failures, test fixtures and acceptance cases.
- A task is `IMPLEMENTED` only with connected non-placeholder code and data migration where required.
- A task is `VERIFIED` only with passing automated tests **and** target-environment evidence. Tests against mocked YouTube responses do not prove a real upload.
- A task is `RELEASED` only after peer/human review, security/rights acceptance and regression results. “Fully autonomous” describes bounded pipeline execution, not bypassing the gates.
- Every module needs golden-path, empty-data, malformed-data, source-conflict, timeout, cancellation, duplicate, and restart-recovery tests.

## E. Data, consent and privacy

- Run HTTP on `127.0.0.1` by default; no LAN/WAN listening without explicit secure setup.
- Bind YouTube credentials separately per authorized channel. Use least-privilege OAuth and encrypted OS credential storage. Never log access/refresh tokens.
- Sandbox/validate downloaded media and untrusted webpages; no executing retrieved instructions. Implement domain allowlists/denylist for SSRF and redirect rechecks. Never use an LLM to approve its own safety exceptions.
- Immutable evidence versions + cited passage/timecode references; hash source bytes; respect retention, licensing, confidentiality and personal data minimization.
- All published outputs require a rights manifest, disclosure assessment, source-to-script attribution for factual claims, originality assessment and editorial audit trail.

## F. System-wide ID/type conventions

- Immutable UUID v4 identifiers. `source_version_id` identifies actual retrieved bytes, `source_id` identifies canonical source; never overwrite a source version.
- All timestamps UTC ISO 8601 with timezone; store original time zone separately if materially important. Monetary values in integer minor units + ISO currency code, not floating-point approximations.
- SQLite text for JSON must pass JSON schema validation in application; canonical models in `contracts/`.
- Use `contract_version` semver-compatible and refuse unknown major versions; migrations must be additive/reversible via tested backups.
- File artifacts referenced by content hash SHA-256 and relative paths under a configured local workspace, not arbitrary paths supplied by external content.

## G. Failure semantics

Failures map to structured code from `core/03_WORKFLOWS_AND_ERRORS.md`; any downstream node depending on a failed prerequisite is `BLOCKED`, not silently skipped. Missing critical evidence => no verified script claim. Missing rights => no render inclusion or publish. Missing approvals => export draft allowed with watermark/label if appropriate, **not** public upload. An unknown live service response triggers retry/backoff or manual review, never a fabricated success.

## H. Change control

- Requirement additions and version changes need an ADR: context, impact, schema migration, risk, tests and owner approval for product changes.
- No direct edits to golden fixtures or test thresholds merely to turn failing tests green.
- A dependency may be upgraded only after compatibility and license validation; current official API docs supersede stale provider assumptions with recorded change.

## I. “Complete” is a verifiable state, not a claim

This pack is intentionally rigorous, but no finite document can guarantee zero omissions or faults. An implementing agent MUST keep its uncertainty, source gaps and blocked decisions visible, deliver verifiable partial code, and never represent speculative or mock work as production capability.
