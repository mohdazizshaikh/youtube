"""Canonical engine name and ownership registry; implementation status is never implied."""
from pathlib import Path
import json,csv
P=Path(__file__).resolve().parents[1]
shared=[
 ('connector_registry','source connectors and permitted provider quotas','core/11_CONNECTORS_AND_INTEGRATIONS.md'),
 ('trend_observatory','topic time series, source coverage and lifecycle','core/04_TREND_DISCOVERY_AND_OPPORTUNITY.md'),
 ('opportunity_score','source-backed explainable recommendation score','core/04_TREND_DISCOVERY_AND_OPPORTUNITY.md'),
 ('research_planner','research questions, stopping criteria and budget','core/05_EVIDENCE_RESEARCH_AND_VERIFICATION.md'),
 ('source_version_store','immutable evidence captures and hashes','core/02_STORAGE_AND_DATA_LIFECYCLE.md'),
 ('evidence_graph','atomic claims and source passage edges','core/05_EVIDENCE_RESEARCH_AND_VERIFICATION.md'),
 ('source_independence','syndication groups and provenance relations','core/05_EVIDENCE_RESEARCH_AND_VERIFICATION.md'),
 ('adversarial_challenger','strongest opposing evidence and open questions','core/05_EVIDENCE_RESEARCH_AND_VERIFICATION.md'),
 ('research_completeness','unanswered question and coverage auditor','core/05_EVIDENCE_RESEARCH_AND_VERIFICATION.md'),
 ('domain_router','domain plugin selection, relevance and different angles','core/00_SYSTEM_ARCHITECTURE.md'),
 ('editorial_decision_council','risk policy, resource allocation and human gate','core/03_WORKFLOWS_AND_ERRORS.md'),
 ('narrative_director','honest hooks, intent and original source-backed story','core/06_AUDIENCE_CREATOR_AND_LEARNING.md'),
 ('portfolio_optimizer','content balance, fatigue and duplicate prevention','core/06_AUDIENCE_CREATOR_AND_LEARNING.md'),
 ('creator_strategy_analyzer','public technique analysis without copying','core/06_AUDIENCE_CREATOR_AND_LEARNING.md'),
 ('script_to_scene_planner','structured SceneSpecs sourced to script and claims','core/07_CREATIVE_MEDIA_AND_PROMPT_ENGINE.md'),
 ('rights_and_originality','license, original value and reused media gates','core/09_YOUTUBE_COMPLIANCE_PUBLISHING_REVENUE.md'),
 ('cpu_media_renderer','diagrams, TTS, subtitles, FFmpeg CPU outputs','core/07_CREATIVE_MEDIA_AND_PROMPT_ENGINE.md'),
 ('cinematic_prompt_compiler','model-specific shot prompt with model evidence','core/07_CREATIVE_MEDIA_AND_PROMPT_ENGINE.md'),
 ('motion_continuity','character, prop, location and motion reference control','core/07_CREATIVE_MEDIA_AND_PROMPT_ENGINE.md'),
 ('temporal_visual_qa','flicker, identity drift, scientific and factual scene checks','core/07_CREATIVE_MEDIA_AND_PROMPT_ENGINE.md'),
 ('compute_scheduler','CPU/CUDA/hybrid/remote admission and reservations','core/08_COMPUTE_MODELS_AND_SCALE.md'),
 ('model_registry','model digest, license, hardware and capabilities','core/08_COMPUTE_MODELS_AND_SCALE.md'),
 ('publishing_director','metadata, approval and official authorized publishing','core/09_YOUTUBE_COMPLIANCE_PUBLISHING_REVENUE.md'),
 ('analytics_learning','authentic analytics, experiments and corrections','core/06_AUDIENCE_CREATOR_AND_LEARNING.md'),
 ('revenue_gpu_fund','actual earnings minus costs and savings towards GPU','core/09_YOUTUBE_COMPLIANCE_PUBLISHING_REVENUE.md'),
 ('job_recovery','state transitions, retries, checkpoint, backup and diagnostics','core/03_WORKFLOWS_AND_ERRORS.md')]
domains={
 'newsroom':['event_verification','full_speech_parser','claim_atomizer','historical_statement_memory','consistency_contradiction','policy_action_outcome','perspective_counterevidence','media_ownership_influence_graph','right_of_reply','investigative_memory','newsroom_visual_policy','newsroom_legal_review'],
 'science':['paper_discovery','methods_examiner','quantitative_calculator','replication_consensus','mechanism_explainer','retraction_monitor','scientific_visualizer','adversarial_scientific_review'],
 'technology':['release_monitor','vendor_claims_extractor','reproducible_test_harness','benchmark_normalizer','security_privacy_examiner','cost_license_analyzer','tutorial_compiler','version_drift_monitor'],
 'business':['filing_intake','financial_normalizer','arithmetic_auditor','ownership_influence','unit_economics','competitive_landscape','forecast_sensitivity','governance_adversarial_review'],
 'gaming':['game_patch_monitor','mechanics_knowledge','replay_ingest','highlight_selector','strategy_evaluator','community_question_miner','gameplay_storyteller','publisher_rights_checker'],
 'history':['archive_explorer','provenance_authenticity','chronology_builder','historical_geography','historiography_challenger','myth_checker','translation_reviewer','reconstruction_director'],
 'space':['mission_monitor','observation_paper_research','orbital_unit_validator','cosmic_scale_graphics','imaging_provenance','space_myth_checker','mission_timeline_director','physics_critic'],
 'learning':['objective_decomposer','prerequisite_mapper','misconception_finder','lesson_planner','example_generator','assessment_builder','explanation_critic','accessibility_layout_director','learning_outcome_reviewer'],
 'sports':['event_calendar','entity_resolver','stat_validator','performance_trend','tactics_board','injury_roster_monitor','match_storyline','rights_safe_footage_planner','sports_community_questions','seasonality_planner',
  'cricket_fixture_score_intake','cricket_score_semantics','cricket_tactical_graphics','cricket_editorial_angles','cricket_rights',
  'nfl_schedule_status','nfl_play_state_parser','nfl_tactics_animator','nfl_performance_analysis','nfl_rights',
  'mlb_innings_stats','mlb_pitcher_hitter','mlb_strike_zone_diagram','mlb_offseason_planner',
  'nba_possession_metrics','nba_tactics_visualizer','soccer_xg_provenance','soccer_formations'],
 'career':['labor_demand_radar','salary_context_validator','skill_graph','credential_verifier','practical_project_lab','interview_resume_coach','career_risk_reviewer'],
 'productivity':['workflow_recorder','bottleneck_finder','automation_planner','before_after_evaluator','template_designer','tool_comparator','habit_evidence_reviewer'],
 'culture':['trend_origin_tracker','diffusion_map','cultural_context_analyzer','myth_misinformation_critic','creator_attribution_rights','harassment_privacy_gate','internet_story_director']
}
stages={'DISCOVER':['discovery','monitor','radar','calendar','intake','origin_tracker','event_verification','release_monitor','paper_discovery'],
 'VERIFY':['validate','validator','examiner','auditor','reviewer','authenticity','provenance','checker','rights','critic','contradiction','consistency','replication','quantitative','retraction'],
 'CREATE':['story','director','planner','compiler','graphics','animator','visualizer','highlight','lesson','example','reconstruction','timeline','diagram','shot'],
 'LEARN':['learning','outcome','experiment','trend','performance','strategy_evaluator'],
 'PUBLISH':['publishing'], 'INVESTIGATE':['research','archive','history','historical','source','mapper','demand','filing','media_ownership']}

def stage(name):
 for st,terms in stages.items():
  if any(t in name for t in terms):return st
 return 'REASON'
engine_owner={
 'connector_registry':'connector_registry','trend_observatory':'trend_engine','opportunity_score':'trend_engine',
 'research_planner':'research_engine','source_version_store':'evidence_service','evidence_graph':'evidence_service','source_independence':'evidence_service',
 'adversarial_challenger':'research_engine','research_completeness':'research_engine','domain_router':'domain_router','editorial_decision_council':'editorial_council',
 'narrative_director':'creator_studio','portfolio_optimizer':'creator_studio','creator_strategy_analyzer':'creator_studio','script_to_scene_planner':'creator_studio',
 'rights_and_originality':'asset_rights','cpu_media_renderer':'media_pipeline','cinematic_prompt_compiler':'creator_studio','motion_continuity':'creator_studio',
 'temporal_visual_qa':'media_pipeline','compute_scheduler':'compute_scheduler','model_registry':'compute_scheduler','publishing_director':'publication_service',
 'analytics_learning':'analytics_service','revenue_gpu_fund':'revenue_ledger','job_recovery':'audit_backup'}
engine_test={
 'connector_registry':'T-L-003','trend_observatory':'T-L-004','opportunity_score':'T-L-004',
 'research_planner':'T-L-019','source_version_store':'T-L-005','evidence_graph':'T-L-005','source_independence':'T-L-005',
 'adversarial_challenger':'T-L-019','research_completeness':'T-L-019','domain_router':'T-L-006','editorial_decision_council':'T-L-009',
 'narrative_director':'T-L-017','portfolio_optimizer':'T-L-017','creator_strategy_analyzer':'T-L-017','script_to_scene_planner':'T-L-020',
 'rights_and_originality':'T-L-008','cpu_media_renderer':'T-L-007','cinematic_prompt_compiler':'T-U-C07','motion_continuity':'T-U-C07',
 'temporal_visual_qa':'T-U-C10','compute_scheduler':'T-L-013','model_registry':'T-U-C08','publishing_director':'T-L-021',
 'analytics_learning':'T-L-011','revenue_gpu_fund':'T-L-012','job_recovery':'T-L-014'}
entries=[]
for name,desc,doc in shared:
 entries.append({'engine_id':'shared.'+name,'owner_module':engine_owner[name],'domain_id':None,'pipeline_stage':stage(name),'algorithm_spec':doc,'purpose':desc,'input_contract':'core contract: source versions/channel/project/job refs','output_contract':'versioned core record, review gate or asset ref','automation_level':'BOUNDED_AUTOMATIC','fail_closed':True,'status':'SPECIFIED','test_ref':engine_test[name]})
for domain,enames in domains.items():
 for name in enames:
  human='right_of_reply' in name or 'legal_review' in name or 'governance_adversarial' in name or 'career_risk' in name
  entries.append({'engine_id':domain+'.'+name,'owner_module':'domain_router','domain_id':domain,'pipeline_stage':stage(name),'algorithm_spec':'domains/'+domain+'.md','purpose':name.replace('_',' '),'input_contract':'DomainContext + canonical SourceVersion/ResearchPlan/SceneSpec refs','output_contract':'OperationResult + domain-typed verified/reviewed artifact refs','automation_level':'HUMAN_REVIEW_REQUIRED' if human else 'BOUNDED_AUTOMATIC','fail_closed':True,'status':'SPECIFIED','test_ref':'T-U-D'+format(list(domains).index(domain)+1,'02')})
assert len({x['engine_id'] for x in entries})==len(entries)
(P/'configs/engine_registry.json').write_text(json.dumps({'contract_version':'2.0.0','note':'Unique authority. This is not implementation; each behavior in linked normative dossier.','engines':entries},indent=2)+'\n')
with (P/'tests/ENGINE_TRACEABILITY.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=['engine_id','owner_module','domain_id','algorithm_spec','status'])
 w.writeheader();w.writerows({k:e[k] for k in w.fieldnames} for e in entries)
print('engines',len(entries),'shared',len(shared),'domain-specific',len(entries)-len(shared))
