#!/usr/bin/env python3
"""Build two self-contained Markdown agent documents from canonical specification files.

Standalone documents are a *snapshot* of the canonical pack, not a second spec owner.
Never hand-edit generated standalones. Rebuild after canonical spec changes.
"""
from pathlib import Path
import hashlib
P=Path(__file__).resolve().parents[1]
OUT=P/'standalone';OUT.mkdir(exist_ok=True)
COMMON=[
 'SPEC_AUTHORITY_AND_AGENT_RULES.md','AUDIT_AND_CHANGELOG.md','AGENT_IMPLEMENTATION_RUNBOOK.md',
 'AGENT_BOOTSTRAP_PROMPT.md',
 *[str(p.relative_to(P)) for p in sorted((P/'core').glob('*.md'))],
 'configs/domain_registry.json','configs/engine_registry.json','configs/default_policy.json','configs/connector_inventory.json','configs/decision_register.json',
 'contracts/interfaces.py','contracts/openapi.yaml',
 *[str(p.relative_to(P)) for p in sorted((P/'contracts').glob('*.schema.json'))],
 'database/schema.sql',
 'tests/REQUIREMENTS.csv','tests/ACCEPTANCE_MATRIX.csv','tests/ADVERSARIAL_TESTS.csv','tests/ENGINE_TRACEABILITY.csv','tests/SYNTHETIC_FIXTURES.json'
]

def doc_intro(edition):
 return f'''# ViralOS {edition} — SELF-CONTAINED AGENT-READY SPECIFICATION v2.0\n\n**Document type:** Engineering instructions and contracts, NOT a working application.\n**Date:** 2026-11-09.\n**Authority:** This file is a compiled, immutable snapshot of the named files in the canonical ZIP; if the ZIP is available use its file hierarchy as source of truth.\n**Do not assume missing source/API access, OAuth credentials, game footage rights, model downloads, revenue or GPU hardware.** Missing inputs become visible blockers.\n\n## How to implement from this one file\n\n1. Read the `SPEC_AUTHORITY_AND_AGENT_RULES.md` section below before any code.\n2. Follow the selected `projects/...` section and use every `core/...` section as canonical shared service specification.\n3. Treat `domains/...` sections as independent domain adapters only; no duplicated source stores or publishing clients.\n4. Extract fenced `contracts/` JSON schemas and `database/schema.sql` to real files before coding.\n5. Follow the test registries at the end; statuses are `SPECIFIED`, not `PASSED`.\n6. Return test evidence/uncertainty, do not claim perfection or guaranteed income.\n\nAll sections marked `BEGIN CANONICAL FILE` are literal generated copies; they must not be independently edited.\n\n'''

def render_section(relative):
 path=P/relative
 s=path.read_text(encoding='utf-8')
 sha=hashlib.sha256(s.encode('utf-8')).hexdigest()
 suffix=path.suffix.lower()
 if suffix in ('.json','.sql','.yaml','.yml','.py','.csv'):
  language={'.json':'json','.sql':'sql','.yaml':'yaml','.yml':'yaml','.py':'python','.csv':'csv'}[suffix]
  data='```'+language+'\n'+s.rstrip()+'\n```\n'
 else:
  data=s.rstrip()+'\n'
 return f'\n---\n\n## BEGIN CANONICAL FILE: `{relative}`\n\n**SHA-256:** `{sha}`\n\n{data}\n**END CANONICAL FILE: `{relative}`**\n'

specs={
 'Launch': ['projects/LAUNCH_EXECUTION_SPEC.md',*COMMON,'domains/sports.md','domains/technology.md'],
 'Ultimate': ['projects/LAUNCH_EXECUTION_SPEC.md','projects/ULTIMATE_EXECUTION_SPEC.md',*COMMON,*[str(p.relative_to(P)) for p in sorted((P/'domains').glob('*.md'))]]
}
for edition,items in specs.items():
 unique=list(dict.fromkeys(items))
 text=doc_intro(edition)+''.join(render_section(x) for x in unique)
 path=OUT/f'ViralOS_{edition}_Standalone_v2.md'
 path.write_text(text,encoding='utf-8')
 print(path,len(text.encode('utf-8')),'bytes',len(unique),'embedded files')
