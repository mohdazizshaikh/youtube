from pathlib import Path
import csv,json
P=Path(__file__).resolve().parents[1]
T=P/'tests'; T.mkdir(exist_ok=True)
L=[
('L-001','Windows/CPU install and launcher','system','LAUNCH','P0','M0','T-L-001'),
('L-002','Channel profile isolation and persistence','channel_registry','LAUNCH','P0','M1','T-L-002'),
('L-003','Cricket/NFL permitted sports source intake','connector_registry','LAUNCH','P0','M2','T-L-003'),
('L-004','Trend coverage and source health','trend_engine','LAUNCH','P0','M2','T-L-004'),
('L-005','Passage-level claims and source provenance','evidence_service','LAUNCH','P0','M2','T-L-005'),
('L-006','Cricket/NFL domain-distinct creative rules','domain_router','LAUNCH','P0','M2','T-L-006'),
('L-007','CPU original Short and long-form video','media_pipeline','LAUNCH','P0','M3','T-L-007'),
('L-008','Rights and substantive originality gate','asset_rights','LAUNCH','P0','M3','T-L-008'),
('L-009','Editorial approval and correction invalidation','editorial_council','LAUNCH','P0','M3','T-L-009'),
('L-010','Manual export and optional authorized YouTube upload','publication_service','LAUNCH','P0','M4','T-L-010'),
('L-011','Actual analytics, experiments and unavailable state','analytics_service','LAUNCH','P0','M4','T-L-011'),
('L-012','Actual revenue/expenses and GPU savings','revenue_ledger','LAUNCH','P0','M5','T-L-012'),
('L-013','CPU/GPU/Auto/Hybrid scheduler','compute_scheduler','LAUNCH','P0','M1','T-L-013'),
('L-014','Durable job recovery and backup/restore','audit_backup','LAUNCH','P0','M1','T-L-014'),
('L-015','Secrets and secure untrusted source ingestion','audit_backup','LAUNCH','P0','M1','T-L-015'),
('L-016','Goldens, reproducibility and release QA','audit_backup','LAUNCH','P0','M5','T-L-016'),
('L-017','Audience intent, truthful narratives, dedupe','creator_studio','LAUNCH','P0','M3','T-L-017'),
('L-018','Versioned API, schema migrations and idempotency','channel_registry','LAUNCH','P0','M1','T-L-018'),
('L-019','Bounded research, completeness, counterevidence','research_engine','LAUNCH','P0','M2','T-L-019'),
('L-020','Original script storyboard and revision validity','creator_studio','LAUNCH','P0','M3','T-L-020'),
('L-021','Truthful metadata and disclosure-linked publish intent','publication_service','LAUNCH','P0','M4','T-L-021'),
('L-022','Actionable dashboard, honest blocker states','channel_registry','LAUNCH','P0','M5','T-L-022')]
U=[
('U-C01','Global multi-source trend and coverage federation','trend_engine'),
('U-C02','Evidence graph, historical memory and corrections','evidence_service'),
('U-C03','Adversarial investigation and completeness','research_engine'),
('U-C04','Cross-domain routing and duplicate prevention','domain_router'),
('U-C05','Audience segmentation and controlled experiments','analytics_service'),
('U-C06','Publishing Director and rights/risk governance','editorial_council'),
('U-C07','Cinematic Prompt Intelligence Engine and continuity','creator_studio'),
('U-C08','GPU local image/video model adapters','media_pipeline'),
('U-C09','Multi-GPU/remote resource-aware workers','compute_scheduler'),
('U-C10','Realism, scientific and temporal generation QC','media_pipeline'),
('U-C11','Source licensing, threat model and corrections','asset_rights'),
('U-C12','Optional future SaaS opt-in and tenant migration','audit_backup')]
DOMAINS=['newsroom','science','technology','business','gaming','history','space','learning','sports','career','productivity','culture']
rows=[]
for rid,desc,owner,edition,priority,mile,test in L:
 rows.append(dict(req_id=rid,title=desc,owner_module=owner,edition=edition,priority=priority,milestone=mile,canonical_spec='projects/LAUNCH_EXECUTION_SPEC.md',test_ids=test,status='SPECIFIED'))
for rid,desc,owner in U:
 rows.append(dict(req_id=rid,title=desc,owner_module=owner,edition='ULTIMATE',priority='P1' if rid<'U-C07' else 'P2',milestone='U1-U5',canonical_spec='projects/ULTIMATE_EXECUTION_SPEC.md',test_ids='T-'+rid,status='SPECIFIED'))
for ix,d in enumerate(DOMAINS,1):
 rows.append(dict(req_id=f'U-D{ix:02}',title=f'Complete specialized {d} OS with engines and goldens',owner_module='domain_router',edition='ULTIMATE',priority='P1' if d in ('newsroom','science','technology','sports') else 'P2',milestone='U1-U2',canonical_spec=f'domains/{d}.md',test_ids=f'T-U-D{ix:02}',status='SPECIFIED'))
with (T/'REQUIREMENTS.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)

examples={
 'L-001':('Windows i7/32GB/no CUDA installs and runs, health accurately shows no GPU','BOOT_AND_RESTART'),
 'L-002':('Two channels persist separately; cross-channel OAuth/profile access blocked','CHANNEL_ISOLATION'),
 'L-003':('Permitted sample cricket/NFL result and stale/blocked data recorded with original source','SPORTS_SOURCE_CONTRACT'),
 'L-004':('Unavailable provider shown as incomplete, no made-up viral score','TREND_COVERAGE_GAP'),
 'L-005':('Each critical factual script sentence has SourceVersion locator or fails QA','CLAIM_CITATION_LINEAGE'),
 'L-006':('Cricket vs NFL output has distinct stats, format, visuals, terminology and validation','SPORT_SPECIALIZATION'),
 'L-007':('Playable original 9:16 and 16:9 CPU outputs, with narration, captions and metadata','CPU_RENDER_2_FORMATS'),
 'L-008':('Protected broadcast video with unknown rights and cosmetic repost fail hard gate','RIGHTS_REUSE_DENIAL'),
 'L-009':('Risky allegation cannot publish; material edit invalidates approval','EDITORIAL_EXPIRY'),
 'L-010':('Manual export works disconnected; consented upload reconciles duplicates','YT_UPLOAD_SAFETY'),
 'L-011':('No synthetic fixtures in observed Analytics; missing OAuth yields unavailable label','ACTUAL_ANALYTICS_ONLY'),
 'L-012':('No estimated RPM added to actual income/savings; currency minor units correct','LEDGER_ACTUAL_VS_ESTIMATE'),
 'L-013':('No GPU under CUDA mode yields safe waiting; CPU still completes','CAPABILITY_ADMISSION'),
 'L-014':('Killed render resumes/restarts idempotently; verified DB+artifact restore','CRASH_RECOVERY'),
 'L-015':('OAuth tokens redacted and persisted encrypted; SSRF redirect denied','SECURITY_BOUNDARIES'),
 'L-016':('Golden source/stats/QC suite reproducible; real Windows evidence attached','EVALUATION_PROTOCOL'),
 'L-017':('Near-duplicate across channels held; misleading hooks rejected','ORIGINAL_ANGLE'),
 'L-018':('Unknown schema major version rejected and duplicate idempotency hash conflict 409','API_CONTRACT_VERSION'),
 'L-019':('Unreachable original speech and opposing evidence become explicit research gaps','RESEARCH_COVERAGE'),
 'L-020':('Source claim IDs in SceneSpec match script; editing source invalidates approval','SCRIPT_REVISION'),
 'L-021':('Thumbnail/title claims derived from approved script and synthetic disclosure set','PUBLISH_METADATA'),
 'L-022':('All UI controls wired; error action and source gap displayed; no fake GPU UI','UI_BLOCKER_STATE')}
tests=[]
for row in rows:
 rid=row['req_id'];tid='T-'+rid
 if rid.startswith('L-'):
  description,fixture=examples[rid]
 elif rid.startswith('U-D'):
  d=DOMAINS[int(rid[-2:])-1];description=f'Domain {d}: authentic source, domain tool, negative edge case, correct video visual grammar, human review';fixture=f'DOMAIN_{d.upper()}_GOLDEN'
 else:
  description=row['title']+' — happy path, rights/evidence failure, cancel/restart and contract regression';fixture='ADVANCED_CORE_GOLDEN'
 tests.append(dict(test_id=tid,req_id=rid,test_type='E2E' if rid.startswith('L-') else 'INTEGRATION',fixture_id=fixture,expected_result=description,status='SPEC_DEFINED',evidence_path=''))
with (T/'ACCEPTANCE_MATRIX.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=tests[0]);w.writeheader();w.writerows(tests)

negative_tests=[
 ('N-001','Cricket 17.3 overs to legal balls','17.3 -> 105; not decimal 17.3'),
 ('N-002','Twenty duplicate news stories','1 provenance family, no 20 independent corroborations'),
 ('N-003','Viral fake sports score','No verified score without official observed source and timestamp'),
 ('N-004','Clip vs full speech context','Out-of-context or NEEDS_REVIEW, not auto liar label'),
 ('N-005','Broadcast replay with face overlay','Unknown rights still block; YouTube reused-content audit separate'),
 ('N-006','Model says test succeeded','No technical result accepted without actual test log'),
 ('N-007','AI image of political event','Clearly labeled synthetic reconstruction and human review'),
 ('N-008','No GPU selected CUDA_ONLY','WAITING_FOR_CAPABILITY; baseline CPU job unaffected'),
 ('N-009','Revoked YouTube access','Upload blocked, no upload success fake'),
 ('N-010','Unknown retention percentage metric','Display unavailable, not 0 or fabricated'),
 ('N-011','Corrupt source capture','Integrity error; no cited verified claim'),
 ('N-012','Post-approval changed source claim','Invalidate approval, stop scheduled public upload'),
 ('N-013','Same YouTube retry after timeout','Reconcile remote before resend; no duplicate'),
 ('N-014','Research page prompt injection','Never execute instructions, treat as untrusted webpage'),
 ('N-015','Backup missing asset file','Restore test fails rather than passes'),
 ('N-016','Cross-channel analytics leakage','Unauthorized channel metrics inaccessible'),
 ('N-017','Source says preprint is peer-reviewed','Paper status checked, claim corrected'),
 ('N-018','BCE date conversion','No year zero, correct timeline'),
 ('N-019','Company thousands vs millions','Unit normalization flags mismatch'),
 ('N-020','Job needs unavailable secret/paid API','Explicit blocker, no invented credential or API response')]
with (T/'ADVERSARIAL_TESTS.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.writer(f);w.writerow(['test_id','scenario','expected_result','status']);w.writerows([*x,'SPEC_DEFINED'] for x in negative_tests)

fixture={'synthetic_test_fixture':True,'warning':'These are testing inputs. Do NOT use as observed real sports/results or YouTube metrics.','contract_version':'2.0.0','samples':{'cricket_overs':{'notation':'17.3','legal_balls':105,'runs':174,'run_rate':9.942857142857143},'source_independence':{'headline_copies':20,'original_reporting_families':1},'channel':{'market':'IN','locale':'hi-IN','domain_id':'sports','sport_id':'cricket'},'gpu':{'dedicated_gpu_present':False,'requested_compute_mode':'CUDA_ONLY','expected_state':'WAITING_FOR_CAPABILITY'},'youtube':{'oauth_connected':False,'expected_publish':'BLOCKED','manual_export_allowed':True}}}
(T/'SYNTHETIC_FIXTURES.json').write_text(json.dumps(fixture,indent=2,ensure_ascii=False)+'\n')

print(len(rows),'requirements',len(tests),'acceptance tests',len(negative_tests),'adversarial tests')
