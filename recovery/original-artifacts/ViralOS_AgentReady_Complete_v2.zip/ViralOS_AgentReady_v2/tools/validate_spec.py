#!/usr/bin/env python3
"""Validate internal consistency of ViralOS spec package. NOT application or live API verification."""
from __future__ import annotations
from pathlib import Path
import csv, hashlib, json, sqlite3, sys
P=Path(__file__).resolve().parents[1]
errors=[]; warnings=[]

def check(ok,why):
 if not ok: errors.append(why)

def jload(path):
 try:return json.loads(path.read_text(encoding='utf-8'))
 except Exception as e:errors.append(f'{path.name} invalid JSON: {e}');return None

# Required structure, exact domain count and registry ownership
needed=['README_START_HERE.md','SPEC_AUTHORITY_AND_AGENT_RULES.md','AUDIT_AND_CHANGELOG.md','AGENT_IMPLEMENTATION_RUNBOOK.md','AGENT_BOOTSTRAP_PROMPT.md','projects/LAUNCH_EXECUTION_SPEC.md','projects/ULTIMATE_EXECUTION_SPEC.md','database/schema.sql','configs/domain_registry.json','configs/default_policy.json','configs/decision_register.json','tests/REQUIREMENTS.csv','tests/ACCEPTANCE_MATRIX.csv','tests/ADVERSARIAL_TESTS.csv']
for rel in needed:check((P/rel).is_file(),f'Missing required artifact: {rel}')
reg=jload(P/'configs/domain_registry.json') or {}
domains=(reg.get('domains') or [])
valid_ids={'newsroom','science','technology','business','gaming','history','space','learning','sports','career','productivity','culture'}
ids=[d.get('domain_id') for d in domains]
check(len(ids)==12 and set(ids)==valid_ids and len(set(ids))==len(ids),'Domain registry must contain exactly 12 unique canonical domain IDs')
files=[p.name for p in (P/'domains').glob('*.md')]
check(set(files)=={d+'.md' for d in valid_ids},f'Domain dossiers mismatch: {set(files)^{d+".md" for d in valid_ids}}')
for d in domains:
 path=P/d.get('dossier','')
 check(path.is_file(),f'Domain file path missing: {d}')
 if path.is_file():
  s=path.read_text(encoding='utf-8')
  check(f'`{d["domain_id"]}`' in s,f'Domain dossier missing ID reference: {path.name}')
check(reg.get('sports_subadapters')==['cricket','nfl','mlb','nba','soccer'],'Sports adapters must match v2.0 canonical set')

# Policies contain known IDs / feature flags
policy=jload(P/'configs/default_policy.json') or {}
check(set(policy.get('release_profiles',{}).get('ULTIMATE',{}).get('all_domains',[]))==valid_ids,'Ultimate profile missing some domains')
check(policy.get('workflow',{}).get('default_publish_mode')=='MANUAL','Publishing must default MANUAL')
check(policy.get('workflow',{}).get('no_rights_no_publish') is True,'Rights hard gate disabled')
check(policy.get('workflow',{}).get('no_evidence_no_verified_factual_claim') is True,'Evidence hard gate disabled')

# JSON Schemas syntax, draft schema checks, aligned enum domains
schema_files=list((P/'contracts').glob('*.schema.json'))
check(len(schema_files)>=16,'Insufficient machine-readable contracts')
try:
 from jsonschema.validators import Draft202012Validator
except ImportError:
 Draft202012Validator=None; warnings.append('jsonschema not installed; only JSON syntax validated')
for path in schema_files:
 d=jload(path)
 if d is None:continue
 check(d.get('properties',{}).get('contract_version',{}).get('const')=='2.0.0',f'{path.name}: unexpected contract version')
 check(d.get('additionalProperties') is False,f'{path.name}: unknown props must fail closed')
 if Draft202012Validator:
  try:Draft202012Validator.check_schema(d)
  except Exception as e:errors.append(f'{path.name} bad schema: {e}')

# Engine ownership registry (one engine ID, one true canonical owner and test)
engreg=jload(P/'configs/engine_registry.json') or {}
engs=engreg.get('engines') or []
engids=[x.get('engine_id') for x in engs]
check(len(engs)>=140 and len(engids)==len(set(engids)),'Engine IDs missing or duplicated')
canonical_owners={'channel_registry','connector_registry','trend_engine','research_engine',
 'evidence_service','domain_router','editorial_council','creator_studio','media_pipeline',
 'compute_scheduler','publication_service','analytics_service','revenue_ledger','asset_rights','audit_backup'}
for e in engs:
 check(e.get('owner_module') in canonical_owners,f'Engine {e.get("engine_id")} has unregistered owner {e.get("owner_module")}')
 check(e.get('domain_id') is None or e.get('domain_id') in valid_ids,f'Unknown domain for engine {e.get("engine_id")}')
 check((P/e.get('algorithm_spec','')).is_file(),f'Engine {e.get("engine_id")} missing algorithm dossier')
 check(e.get('status')=='SPECIFIED',f'Engine falsely marked implemented: {e.get("engine_id")}')

# Check OpenAPI is valid YAML where PyYAML is installed and references local schema files
try:
 import yaml
 openapi=yaml.safe_load((P/'contracts/openapi.yaml').read_text(encoding='utf-8'))
 paths=openapi.get('paths',{})
 check(len(paths)>=30,'OpenAPI routes unexpectedly missing')
 for route,methods in paths.items():
  for method,details in methods.items():
   if method in ('parameters','summary','description'):continue
   check('operationId' in details,f'Missing operationId in {route} {method}')
 for name in ['ChannelProfile','ResearchPlan','ContentProject','SceneSpec','PublicationIntent','ApprovalRecord']:
  check((P/'contracts'/f'{name}.schema.json').exists(),f'Missing OpenAPI contract {name}')
except ImportError:
 warnings.append('PyYAML not installed; OpenAPI not parsed')
except Exception as e:errors.append(f'OpenAPI validation failed: {e}')

# Syntax-check normative Python Protocol interfaces
try:
 import ast
 ast.parse((P/'contracts/interfaces.py').read_text(encoding='utf-8'))
except Exception as e:errors.append(f'Bad interface syntax: {e}')

# Requirement and acceptance test references
try:
 with (P/'tests/REQUIREMENTS.csv').open(newline='',encoding='utf-8') as f:rq=list(csv.DictReader(f))
 with (P/'tests/ACCEPTANCE_MATRIX.csv').open(newline='',encoding='utf-8') as f:ac=list(csv.DictReader(f))
 rids=[r['req_id'] for r in rq];tids=[r['test_id'] for r in ac]
 check(len(rids)==len(set(rids)),'Duplicate requirement IDs')
 check(len(tids)==len(set(tids)),'Duplicate acceptance test IDs')
 check(len(rids)>=46,'Requirement registry unexpectedly truncated')
 for r in rq:
  check((P/r['canonical_spec']).is_file(),f'Missing requirement owner spec {r["req_id"]}: {r["canonical_spec"]}')
  check(r['status']=='SPECIFIED',f'Requirement falsely pre-verified {r["req_id"]}')
  check(r['test_ids'] in tids,f'Unknown acceptance test {r["test_ids"]} in {r["req_id"]}')
 for a in ac:
  check(a['req_id'] in rids,f'Test {a["test_id"]} references missing requirement {a["req_id"]}')
  check(a['status']=='SPEC_DEFINED',f'Test falsely pre-passed: {a["test_id"]}')
 for e in engs:
  check(e.get('test_ref') in tids,f'Engine {e.get("engine_id")} references unknown test: {e.get("test_ref")}')
 for i in range(1,23):check(f'L-{i:03d}' in rids,f'Missing L-{i:03d}')
 for i in range(1,13):check(f'U-D{i:02d}' in rids,f'Missing domain U-D{i:02d}')
except Exception as e:errors.append(f'Test matrix read error: {e}')

# SQLite parse, schema integrity, source immutability and basic ref constraints
try:
 conn=sqlite3.connect(':memory:')
 conn.executescript((P/'database/schema.sql').read_text(encoding='utf-8'))
 conn.execute('PRAGMA foreign_keys=ON')
 check(conn.execute('PRAGMA foreign_keys').fetchone()[0]==1,'SQLite foreign keys off')
 tables={x[0] for x in conn.execute("select name from sqlite_master where type='table'")}
 for name in ['domains','channels','topics','source_versions','evidence_edges','content_projects','scenes','render_attempts','approvals','publication_intents','analytics_snapshots','revenue_entries','jobs','audit_events']:
  check(name in tables,f'DB missing table {name}')
 # FK constraint on cross-entity insertion, fails by design
 try:
  conn.execute("insert into channels(channel_id,domain_id,name,locale,market,timezone,risk_policy_id,created_at,updated_at) values ('x','fictional','Test','hi-IN','IN','Asia/Kolkata','standard','2026-11-09T00:00:00Z','2026-11-09T00:00:00Z')")
  errors.append('Unknown domain channel accepted')
 except sqlite3.IntegrityError: pass
 check(conn.execute('PRAGMA integrity_check').fetchone()[0]=='ok','SQLite integrity check failed')
 conn.close()
except Exception as e:errors.append(f'Bad SQL schema or SQLite test: {e}')

# Distinguish synthetic fixtures from production data
fx=jload(P/'tests/SYNTHETIC_FIXTURES.json') or {}
check(fx.get('synthetic_test_fixture') is True,'Test fixtures need synthetic flag')
check(fx.get('samples',{}).get('cricket_overs',{}).get('legal_balls')==105,'Cricket base-six fixture wrong')

# Older sources retained for audit
for fn in ['Launch_v1_1_ORIGINAL.md','Ultimate_v1_1_ORIGINAL.md']:
 check((P/'source_snapshots'/fn).is_file(),f'Old snapshot missing: {fn}')

# Summary
print(f'SPEC VALIDATION: domains={len(domains)}, engines={len(engs)}, contracts={len(schema_files)}, api_routes={len(paths) if "paths" in locals() else 0}, requirements={len(rq) if "rq" in locals() else 0}, acceptance={len(ac) if "ac" in locals() else 0}')
for w in warnings:print('WARN:',w)
for e in errors:print('ERROR:',e)
print('RESULT:', 'PASS' if not errors else f'FAIL ({len(errors)} errors)')
print('LIMITATION: This tests document formats and constraints only, not actual ViralOS source, APIs, YouTube access, or hardware.')
sys.exit(1 if errors else 0)
