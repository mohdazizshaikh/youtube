# ViralOS_Launch_v2_1 — Independent Specification Package

**Status: PRODUCT + ENGINEERING SPECIFICATION; NOT EXECUTABLE VIRALOS APPLICATION.**

This package is self-contained for its stated scope; do not unpack other edition ZIPs on top of it. `contract_version=2.0.0` intentionally remains compatible with v2 while document spec revision is v2.1.

**Read:** `AGENT_START_HERE.md` -> `SPEC_PRECEDENCE.md` -> `GAP_AUDIT.md` -> `PACK_MANIFEST.json` -> project profile -> `core/14`–`core/20` -> original core, schemas, engines -> selected playbooks -> test matrix.

**Validate locally:** `python tools/validate_pack.py` (Python stdlib; JSON Schema validation adds optional jsonschema). This verifies specification consistency, SQL migration behavior, hashes, registries, but **not software implementation or YouTube monetization**.

**Edition rules:** Launch covers own-YouTube pilot on i7/32GB/no GPU; Ultimate covers all 12 specialized OS; Combined is one monorepo with phase toggles and explicit upgrade path. Never create three conflicting applications or duplicate shared services.

**Still requires real access:** legally permitted source provider/API, own YouTube credentials, copyright/media licenses, approval, actual Windows/FFmpeg tests, GPU drivers/models in future. When absent, show blocker and fallback, not invented results.
