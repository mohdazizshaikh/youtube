# ViralOS Launch — CPU-only Implementation Vertical Slice v0.1

**This is RUNNABLE prototype code, not complete ViralOS.** Scope: one local Windows-compatible workspace, Cricket/NFL channel profiles, manual source/provenance intake, human-reviewed claims, script revisions, user-defined storyboard scenes, original text graphics, optional owner WAV narration, FFmpeg MP4 technical previews and durable job records. This implementation deliberately makes no claims of verified external research, AI-driven scripts, sophisticated automated narration, licensed broadcasts, professional final video, OAuth/YouTube uploads, multi-language dubbing, or monetization. This does **not** replace Launch/Ultimate/Combined v3 specification packages.

## Windows quick start

1. Install Python 3.12 (with `py` launcher), FFmpeg and FFprobe; `ffmpeg -version` and `ffprobe -version` must work in PowerShell.
2. Extract this archive into its own folder. Run `powershell -ExecutionPolicy Bypass -File .\tools\start_windows.ps1`, or manually:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

3. Open **http://127.0.0.1:8000/** for the no-build prototype workbench or **http://127.0.0.1:8000/docs** for the actual API.
4. Create Cricket (hi-IN, India) or NFL (en-US, USA) channel; create an original project, paste an original source excerpt, record an atomic claim, review it yourself, save original narration, add 2–5 original scene texts, and queue/render preview. Original animations are generated using Pillow/FFmpeg; they are **not a copy of match broadcast footage**.
5. For narration, upload an **owner-recorded WAV**. Without it, preview is explicitly silent and watermarked. The prototype does not align subtitles to speech; the on-screen words are titles/scene text only.
6. All output videos remain private/local. YouTube OAuth and publishing are **disabled**.

## Data and security

- Runs on `127.0.0.1` only; never expose externally. No login yet; one user with local computer access controls workspace. No real cloud credentials stored.
- SQLite canonical v3 migration files are included unmodified in `sql/`. They are applied only once with checksum tracking, 61+ canonical tables, WAL and foreign keys.
- `VIRALOS_DB` can override database path for tests/alternate workspace; use a local disk. No destructive migration.
- Source URLs are **never fetched** by this prototype: owner pastes excerpts and asserts review. Source permission/independence are not independently verified.
- `outputs/` stores private WAVs, original scene slides, videos, and `render_manifest.json` with honest `publish_ready=false`.
- Rendering jobs are persisted and sequential; crashed RUNNING jobs are **not yet auto recovered**. Workers are manually triggered. Don't use this as a production publish pipeline.

## Tested and not tested

Tested in development environment (Linux, FFmpeg): API, canonical migration, manual evidence links, claim-review safeguards, original CPU clip generation and MP4 probe. **Not tested on user's Windows i7 PC.** Python and FFmpeg performance, locale font coverage, Piper, React/Vite frontend, professional design, actual footage rights and YouTube integration remain future milestones. This UI is a temporary zero-build diagnostic dashboard; v3 product architecture calls for React and a stable Windows launcher, which will replace it.

## What comes next (in canonical order)

M0: secure localhost app, Windows validation, robust migrations and diagnostics. M1: real source adapters permitted by licenses, independent citation review and research completeness. M2: typed v3 CreativeBrief/ShotPlan/VideoTimeline, locale-specific overlay, tested TTS and audio alignment, original tactical vector diagrams, QA/watch-through workflow. M3: reviewed export/upload and authorized YouTube Analytics. M4: reliable jobs/backup/restore/learning. CPU/GPU/Hybrid adapters and all domain creative directors follow, with tests.

See `docs/STATUS.md` for requirement-level limitations. This prototype is **not** an AI agent, a complete video studio, an approved publication pipeline or a substitute for legal/editorial review.
