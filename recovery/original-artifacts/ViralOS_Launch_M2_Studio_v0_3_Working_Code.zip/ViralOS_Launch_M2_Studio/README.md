# ViralOS Launch M0–M3 assisted development checkpoint

This ZIP contains **runnable Python/FastAPI application code** plus the canonical Launch v3 specification snapshot, Windows scripts, optional research and narration connectors, a diagnostic dashboard, SQL migrations, private export workflow and tests.

**This is an honest engineering checkpoint, not a complete AI autopublisher or professional video studio.** The exact capabilities, limitations, Windows instructions and opt-in Google Analytics setup are in [docs/IMPLEMENTATION_M1_M3.md](docs/IMPLEMENTATION_M1_M3.md).

Quick start (Windows, Python 3.12, FFmpeg installed):

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\start_windows.ps1
```

Open http://127.0.0.1:8000 . Python API docs: http://127.0.0.1:8000/docs .

Modules: `app/main.py` legacy working M0 workflow; `app/expansion.py` new M1/M2/M3 endpoints; `app/intelligence.py` bounded feed/claim/timeline logic; `app/source_connectors.py` explicit approved RSS fetch; `app/tts.py` optional Piper; `app/youtube_analytics.py` optional read-only OAuth/Analytics; `app/renderer.py` original CPU technical render. `sql/004_m1_m3.sql` contains additive durable records.

**Publishing is disabled.** All render artifacts say `NOT PUBLISH READY`. Users must not treat an owner-attested claim or downloaded RSS title as independently verified.

## M2 CPU Studio v0.3 — new in this checkpoint

The old working M0–M3 endpoints, scripts and schema are retained. The new `app/studio_contracts.py`, `app/studio_routes.py` and `app/studio_render.py` provide an **actual CPU-rendered overlay/timeline studio prototype**, SQL migration `005_studio.sql`, rights-attested owner assets, owner-timed captions, WAV duration guard and QC manifest. The dashboard contains the **M2 Studio Director** panel.

Read [docs/M2_STUDIO_IMPLEMENTATION.md](docs/M2_STUDIO_IMPLEMENTATION.md) and [docs/STATUS_M2.md](docs/STATUS_M2.md). Technical video previews remain **NOT PUBLISH READY**. No automatic web footage ingestion, dubbing, GPU generation or uploads are enabled.
