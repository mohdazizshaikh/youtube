# AI CODING AGENT — START HERE, STRICT IMPLEMENTATION PROTOCOL v2.1

You have a **specification package**, not complete application source. First run `python tools/validate_pack.py` and inspect `PACK_MANIFEST.json`; read `SPEC_PRECEDENCE.md`, `GAP_AUDIT.md`, `core/14`–`core/20`, relevant project contract, 12 domain dossiers only where enabled, execution registry and tests. Never merge older snapshots as competing specifications.

**Absolute boundaries:** no fabricated sources, sports stats, benchmark logs, videos, uploads, analytics, revenue, claims, permissions or rights; no reuploading copyrighted sports clips merely cropped/green-screened; no hidden public publishing; no bypass of policy because of viral performance.

Implement in order:
1. Environment discovery and dependency lock; build Windows i7/32GB CPU-first startup on localhost with real file-backed persistence. No GPU hard dependency.
2. Versioned SQLite schema migration, per-channel isolation and secure local settings; create matching endpoint tests.
3. Source qualification and real/manual research attempts with coverage reports; evidence+claim and domain data checks.
4. Sports cricket/NFL distinct real rule implementations; original scripts/storyboards and CPU-safe media output with tested FFmpeg/audio/captions.
5. Rights, factual/technical QA, human approval and export gate. Manual export must work with no OAuth.
6. Optional OAuth YouTube upload with reconciliation, real analytics and revenue only if authorized; otherwise keep honest blocked/not-available UI.
7. Crash/retry/restart/backup tests; owner video review; record measured render performance.
8. Ultimate **after** Launch: implement domain-by-domain with independent tests, GPU generation adapters only after model+driver+license benchmarks, distributed workers only when hardware exists.

For every feature emit: `implemented_files`, `tests_run`, `tests_failed`, `mock_only_tests`, `external_blockers`, `manual_review_needed`, `logs/artifacts`, `residual_risks`, `next_allowed_step`. Never mark a task IMPLEMENTED solely because Markdown exists. If spec conflict, create `SPEC_CONFLICT` issue and halt affected step. Do not expand scope as an excuse for missing core behavior.
