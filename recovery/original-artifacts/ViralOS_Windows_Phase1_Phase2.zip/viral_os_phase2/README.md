# ViralOS Phase 1 + Phase 2 — Windows local MVP

This project extends the previous FastAPI + SQLite starter with a local Ollama adapter, original Pillow slides, optional Piper voice, FFmpeg rendering, a persisted render-job queue, and tests. **Not a production SaaS or fully automated YouTube publisher.**

## Requirements
- Windows 10/11, 16 GB RAM, Intel i5 (integrated graphics supported)
- Python 3.12 (recommended)
- FFmpeg installed and available on PATH (`ffmpeg -version`)
- Optional: Ollama installed, running, and `ollama pull qwen2.5:3b`
- Optional: Piper CLI and a legally obtained voice `.onnx` model; configure `PIPER_MODEL`

## Install — PowerShell
```powershell
cd viral_os_phase2
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
ffmpeg -version
python -m pytest -q
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```
Open http://127.0.0.1:8000/docs . If activation is blocked, run `.\.venv\Scripts\python.exe` instead of `python` (and `-m pip`, `-m pytest`, `-m uvicorn`).

## Local AI (optional)
```powershell
ollama pull qwen2.5:3b
ollama serve
```
In a separate PowerShell terminal start the FastAPI server. To choose another model set `$env:OLLAMA_MODEL='your-model-name'` before starting the API. The `/ideas/{id}/ai-draft` endpoint returns HTTP 503 if Ollama is unavailable; it does not pretend that a template is AI output.

## Offline voice (optional)
Install Piper separately, make `piper.exe` available on PATH, download a Piper `.onnx` voice and matching config, then set `$env:PIPER_MODEL='C:\voices\your-voice.onnx'`. Without Piper, rendering creates a **silent 12-second preview**. For Hindi text, set `$env:VIRALOS_FONT='C:\Windows\Fonts\Nirmala.ttf'` if glyph coverage is needed. The chosen Piper voice must support the script language.

## First end-to-end flow
1. POST `/channels` with `{ "name": "Science Hindi", "niche": "science", "language": "hi" }`.
2. POST `/ideas` with `{ "channel_id": 1, "title": "Why is the sky blue?", "score": 75 }`.
3. POST `/ideas/1/ai-draft` (requires Ollama), OR POST `/ideas/1/draft` with `{ "script": "Your original script of at least twenty characters." }`.
4. POST `/videos/1/assets` with `{ "file_path": "generated-original-slide", "license": "original", "proof": "Original graphic generated locally" }`.
5. POST `/videos/1/approve`.
6. POST `/videos/1/render` to queue; POST `/jobs/run-next` to execute one job.
7. Open `outputs/video_1/preview.mp4`. Check `/jobs` for failures.

## Limitations and security
- The current renderer uses a **single original text slide**, not stock-footage editing or sophisticated multi-scene animation. Hindi shaping depends on installed fonts and Pillow behavior.
- The voice is optional; no Piper = silent preview. No automated fact checking or copyright verification. The asset registry only records a declaration; it does not validate licenses.
- API is **unauthenticated**. Bind only to `127.0.0.1`; never expose to the internet. Jobs run only when `/jobs/run-next` is called; one worker process only. Running jobs interrupted by a crash need manual recovery. SQLite is single-user here.
- No YouTube API/OAuth, no upload or auto-publishing. No guaranteed virality or monetization.
- Existing database schema is preserved; back up `viral.db` before upgrading. This is a starter, not a migration-managed application.

## Next production steps
Auth and per-workspace authorization; schema migrations; a continuously running supervised worker with stale-job recovery; scene-level timelines and subtitle layouts; asset checks; OAuth and private YouTube uploads; analytics; audit logs; tests with a real Ollama/Piper install; React dashboard.
