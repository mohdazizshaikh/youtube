"""Local Ollama adapter; never silently misrepresent fallback as AI."""
import os
import httpx

class AIUnavailable(RuntimeError): pass

def generate_script(topic: str, niche: str, language: str, model: str | None = None) -> str:
    model = model or os.getenv("OLLAMA_MODEL", "qwen2.5:3b")
    prompt = ("Write an ORIGINAL, factual, concise 60-90 word YouTube Short script. "
              "Avoid invented claims, copyrighted quotations and calls to repost. "
              "No markdown. If uncertain, explicitly say so. "
              f"Language: {language}. Niche: {niche}. Topic: {topic}.")
    try:
        with httpx.Client(timeout=150.0) as client:
            response = client.post(os.getenv("OLLAMA_URL", "http://127.0.0.1:11434") + "/api/generate",
                                   json={"model": model, "prompt": prompt, "stream": False,
                                         "options": {"temperature": 0.5, "num_predict": 220}})
            response.raise_for_status()
            text = response.json().get("response", "").strip()
    except (httpx.HTTPError, ValueError) as exc:
        raise AIUnavailable("Ollama unavailable. Start Ollama and pull the configured model.") from exc
    if len(text) < 20:
        raise AIUnavailable("Ollama returned an empty or too-short script")
    return text
