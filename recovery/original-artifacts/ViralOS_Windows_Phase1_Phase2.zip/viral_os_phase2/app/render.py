"""Local CPU-first rendering. Only creates original text graphics."""
from pathlib import Path
import os, re, shutil, subprocess, textwrap
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent.parent
OUTPUT = ROOT / "outputs"

def _font(size: int):
    candidates = [os.getenv("VIRALOS_FONT", ""), "C:/Windows/Fonts/arial.ttf",
                  "C:/Windows/Fonts/Nirmala.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]
    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            return ImageFont.truetype(candidate, size)
    return ImageFont.load_default()

def make_slide(text: str, destination: Path):
    image = Image.new("RGB", (720, 1280), (18, 25, 46))
    draw = ImageDraw.Draw(image)
    font = _font(49)
    small = _font(25)
    # Pixel-aware wrapping; no external stock or third-party footage.
    words = text.split()
    lines, current = [], ""
    for word in words:
        trial = (current + " " + word).strip()
        if draw.textbbox((0,0), trial, font=font)[2] > 630 and current:
            lines.append(current);current=word
        else: current=trial
    if current: lines.append(current)
    lines = lines[:11]
    y = max(180, (1280-len(lines)*75)//2)
    for line in lines:
        draw.text((45,y),line,font=font,fill=(245,247,255));y+=75
    draw.text((45,1120),"ViralOS • Original draft",font=small,fill=(126,190,245))
    destination.parent.mkdir(parents=True,exist_ok=True)
    image.save(destination)

def synthesize_piper(script: str, destination: Path):
    executable = shutil.which("piper")
    model = os.getenv("PIPER_MODEL", "")
    if not executable or not model or not Path(model).is_file():
        return False
    proc = subprocess.run([executable,"--model",model,"--output_file",str(destination)],
                          input=script, text=True, capture_output=True,timeout=180)
    if proc.returncode != 0 or not destination.exists():
        raise RuntimeError("Piper failed: " + proc.stderr[-500:])
    return True

def render_video(video_id: int, script: str) -> str:
    if not shutil.which("ffmpeg"):
        raise RuntimeError("FFmpeg missing from PATH")
    directory = OUTPUT / f"video_{video_id}"
    directory.mkdir(parents=True,exist_ok=True)
    # Single slide keeps CPU/RAM use low; future releases can use multi-scene storyboards.
    slide = directory / "slide.png"
    make_slide(script, slide)
    audio = directory / "voice.wav"
    has_audio = synthesize_piper(script, audio)
    result = directory / "preview.mp4"
    command = ["ffmpeg","-y","-hide_banner","-loglevel","error","-loop","1","-framerate","24","-i",str(slide)]
    if has_audio:
        command += ["-i",str(audio),"-c:a","aac","-b:a","128k","-shortest"]
    else:
        command += ["-t","12"]
    command += ["-vf","scale=720:1280,format=yuv420p","-c:v","libx264","-preset","ultrafast",
                "-crf","28","-r","24","-movflags","+faststart",str(result)]
    try:
        subprocess.run(command,check=True,capture_output=True,text=True,timeout=300)
    except subprocess.CalledProcessError as exc:
        raise RuntimeError("FFmpeg failed: " + exc.stderr[-500:]) from exc
    if not result.exists() or result.stat().st_size == 0:
        raise RuntimeError("Rendered file missing or empty")
    return str(result)
