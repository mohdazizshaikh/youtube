"""Single-job synchronous worker. Run one worker process only."""
from sqlalchemy import select
from .db import SessionLocal
from .models import Job, Video
from .render import render_video

def run_next_job():
    with SessionLocal() as db:
        job = db.scalars(select(Job).where(Job.status == "queued").order_by(Job.id)).first()
        if not job: return None
        job.status="running";job.attempts+=1;db.commit()
        job_id=job.id;video_id=job.video_id
    try:
        with SessionLocal() as db:
            video=db.get(Video,video_id)
            if not video or video.status != "approved":
                raise RuntimeError("Video must be approved before rendering")
            script=video.script
        path=render_video(video_id,script)
        with SessionLocal() as db:
            job=db.get(Job,job_id);video=db.get(Video,video_id)
            video.media_path=path;video.status="rendered";job.status="completed";job.error="";db.commit()
        return {"job_id":job_id,"status":"completed","media_path":path}
    except Exception as exc:
        with SessionLocal() as db:
            job=db.get(Job,job_id);job.status="failed";job.error=str(exc)[:2000];db.commit()
        return {"job_id":job_id,"status":"failed","error":str(exc)}
