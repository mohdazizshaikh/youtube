import os
from pathlib import Path
from unittest.mock import patch
from fastapi.testclient import TestClient
from app.main import app
from app.db import Base, engine
from app.models import Workspace
from app.db import SessionLocal
from app.render import make_slide, render_video

def test_original_slide(tmp_path):
    target=tmp_path/'slide.png'
    make_slide('An original short video about science',target)
    assert target.exists() and target.stat().st_size>1000

def test_render_without_piper(tmp_path, monkeypatch):
    import app.render as render
    monkeypatch.setattr(render,'OUTPUT',tmp_path)
    monkeypatch.delenv('PIPER_MODEL',raising=False)
    output=render_video(999,'Original story for our test video')
    assert Path(output).exists() and Path(output).stat().st_size>1000

def test_api_workflow(monkeypatch, tmp_path):
    import app.worker as worker
    monkeypatch.setattr(worker,'render_video',lambda video_id,script:str(tmp_path/'test.mp4'))
    with TestClient(app) as client:
        ch=client.post('/channels',json={'name':'Test Channel','niche':'Science','language':'en'}).json()
        idea=client.post('/ideas',json={'channel_id':ch['id'],'title':'Why is the sky blue?','score':80}).json()
        video=client.post(f"/ideas/{idea['id']}/draft",json={'script':'This is an original explanatory science video script.'}).json()
        assert client.post(f"/videos/{video['id']}/render").status_code==409
        assert client.post(f"/videos/{video['id']}/approve").status_code==400
        assert client.post(f"/videos/{video['id']}/assets",json={'file_path':'generated-original-slide','license':'original','proof':'Created by author'}).status_code==200
        assert client.post(f"/videos/{video['id']}/approve").status_code==200
        queued=client.post(f"/videos/{video['id']}/render").json()
        assert queued['status']=='queued'
        done=client.post('/jobs/run-next').json()
        assert done['status']=='completed'

def test_ai_failure_is_clear():
    from app.ai import generate_script, AIUnavailable
    with patch('app.ai.httpx.Client') as mock:
        mock.return_value.__enter__.return_value.post.side_effect=__import__('httpx').ConnectError('offline')
        try: generate_script('topic','science','en')
        except AIUnavailable: pass
        else: raise AssertionError('Expected explicit AIUnavailable')
