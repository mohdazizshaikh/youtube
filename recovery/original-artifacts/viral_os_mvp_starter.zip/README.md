# ViralOS Local MVP — v0.1

A working **local-only FastAPI backend** for channel profiles, ranked ideas, scripts, licensed asset records and approval. It **does not yet** discover YouTube trends, generate AI scripts, render video, authenticate users, or upload to YouTube. Do not expose this API to the internet: it uses a single local workspace and has no login.

## Requirements
Python 3.12+ recommended. No paid services required.

## Start
```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```
Open http://127.0.0.1:8000/docs for the interactive API dashboard.

## First test
1. POST `/channels` with `{"name":"AI Hindi","niche":"AI tutorials","language":"hi"}`.
2. POST `/ideas` with `{"channel_id":1,"title":"Three useful AI spreadsheet tricks","score":75}`.
3. POST `/ideas/1/draft` with a 20+ character original script.
4. POST `/videos/1/assets` with `{"file_path":"/my/original/screen.mp4","license":"self-created","proof":"Recorded by me on 2026-11-09"}`.
5. POST `/videos/1/approve`; GET `/videos`.

Asset records are metadata only; the MVP does not validate file existence, license authenticity, or render video. Approval is a workflow marker, not legal clearance.

## Roadmap
- Phase 1: authenticated local user, SQLite migrations, stronger asset checks, channel ownership.
- Phase 2: official YouTube Data API trend importer, caching and quota counters.
- Phase 3: Ollama script drafting with citation review, Piper narration, FFmpeg templates.
- Phase 4: persistent job worker with retries and idempotency; OAuth token encryption.
- Phase 5: private-first upload tests, scheduling, analytics, compliance checks.
- Phase 6: PostgreSQL, tenant isolation, SaaS billing and observability.

## Security
Never commit OAuth secrets. Do not expose `--host 0.0.0.0` without authentication and HTTPS. SaaS needs per-tenant authorization on every query, CSRF protection for cookie auth, encrypted OAuth tokens, rate limits, audit logs and backups.
