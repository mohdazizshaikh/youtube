from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from .db import Base, engine, SessionLocal
from .models import Workspace, Channel, Idea, Video, Job, Asset

@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        if not db.get(Workspace,1):
            db.add(Workspace(id=1,name='Personal workspace')); db.commit()
    yield
app = FastAPI(title='ViralOS Local MVP', lifespan=lifespan)
class ChannelIn(BaseModel):
    name: str = Field(min_length=2,max_length=120)
    niche: str = Field(min_length=2,max_length=120)
    language: str = 'hi'
class IdeaIn(BaseModel):
    channel_id: int
    title: str = Field(min_length=3,max_length=250)
    source_url: str = ''
    score: int = Field(default=0,ge=0,le=100)
class ScriptIn(BaseModel):
    script: str = Field(min_length=20)
class AssetIn(BaseModel):
    file_path: str
    license: str
    proof: str

def serialize(obj,*fields): return {f:getattr(obj,f) for f in fields}
@app.get('/health')
def health(): return {'ok':True,'mode':'local','publishing_enabled':False}
@app.post('/channels')
def create_channel(body:ChannelIn):
    with SessionLocal() as db:
        obj=Channel(workspace_id=1,**body.model_dump());db.add(obj);db.commit();db.refresh(obj)
        return serialize(obj,'id','name','niche','language')
@app.get('/channels')
def channels():
    with SessionLocal() as db:
        return [serialize(c,'id','name','niche','language') for c in db.scalars(select(Channel).where(Channel.workspace_id==1)).all()]
@app.post('/ideas')
def create_idea(body:IdeaIn):
    with SessionLocal() as db:
        c=db.get(Channel,body.channel_id)
        if not c or c.workspace_id!=1: raise HTTPException(404,'Channel not found')
        obj=Idea(workspace_id=1,**body.model_dump());db.add(obj);db.commit();db.refresh(obj)
        return serialize(obj,'id','channel_id','title','score','status')
@app.get('/ideas')
def ideas():
    with SessionLocal() as db:
        return [serialize(i,'id','channel_id','title','score','status') for i in db.scalars(select(Idea).where(Idea.workspace_id==1).order_by(Idea.score.desc())).all()]
@app.post('/ideas/{idea_id}/draft')
def draft(idea_id:int,body:ScriptIn):
    with SessionLocal() as db:
        idea=db.get(Idea,idea_id)
        if not idea or idea.workspace_id!=1: raise HTTPException(404,'Idea not found')
        video=Video(workspace_id=1,channel_id=idea.channel_id,idea_id=idea.id,script=body.script)
        db.add(video);db.commit();db.refresh(video)
        return serialize(video,'id','idea_id','status','script')
@app.post('/videos/{video_id}/assets')
def add_asset(video_id:int,body:AssetIn):
    with SessionLocal() as db:
        video=db.get(Video,video_id)
        if not video or video.workspace_id!=1: raise HTTPException(404,'Video not found')
        if not body.proof.strip() or not body.license.strip(): raise HTTPException(400,'License and proof required')
        asset=Asset(workspace_id=1,video_id=video_id,**body.model_dump());db.add(asset);db.commit();db.refresh(asset)
        return {'id':asset.id,'video_id':video_id,'license':asset.license}
@app.post('/videos/{video_id}/approve')
def approve(video_id:int):
    with SessionLocal() as db:
        video=db.get(Video,video_id)
        if not video or video.workspace_id!=1: raise HTTPException(404,'Video not found')
        if not db.scalars(select(Asset).where(Asset.video_id==video_id,Asset.workspace_id==1)).first():
            raise HTTPException(400,'At least one documented licensed asset required')
        video.status='approved';db.commit();return {'id':video.id,'status':video.status}
@app.get('/videos')
def videos():
    with SessionLocal() as db:
        return [serialize(v,'id','idea_id','channel_id','status','script') for v in db.scalars(select(Video).where(Video.workspace_id==1)).all()]
