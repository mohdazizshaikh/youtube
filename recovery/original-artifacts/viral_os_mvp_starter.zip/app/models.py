from datetime import datetime, timezone
from sqlalchemy import ForeignKey, String, Text, Integer, DateTime, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column
from .db import Base

def utcnow(): return datetime.now(timezone.utc)
class Workspace(Base):
    __tablename__='workspaces'
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
class Channel(Base):
    __tablename__='channels'
    id: Mapped[int] = mapped_column(primary_key=True)
    workspace_id: Mapped[int] = mapped_column(ForeignKey('workspaces.id'))
    name: Mapped[str] = mapped_column(String(120))
    niche: Mapped[str] = mapped_column(String(120))
    language: Mapped[str] = mapped_column(String(30),default='hi')
class Idea(Base):
    __tablename__='ideas'
    id: Mapped[int] = mapped_column(primary_key=True)
    workspace_id: Mapped[int] = mapped_column(ForeignKey('workspaces.id'))
    channel_id: Mapped[int] = mapped_column(ForeignKey('channels.id'))
    title: Mapped[str] = mapped_column(String(250))
    source_url: Mapped[str] = mapped_column(Text,default='')
    score: Mapped[int] = mapped_column(Integer,default=0)
    status: Mapped[str] = mapped_column(String(30),default='candidate')
class Video(Base):
    __tablename__='videos'
    id: Mapped[int] = mapped_column(primary_key=True)
    workspace_id: Mapped[int] = mapped_column(ForeignKey('workspaces.id'))
    channel_id: Mapped[int] = mapped_column(ForeignKey('channels.id'))
    idea_id: Mapped[int] = mapped_column(ForeignKey('ideas.id'))
    script: Mapped[str] = mapped_column(Text,default='')
    media_path: Mapped[str] = mapped_column(Text,default='')
    status: Mapped[str] = mapped_column(String(30),default='draft')
class Job(Base):
    __tablename__='jobs'
    id: Mapped[int] = mapped_column(primary_key=True)
    workspace_id: Mapped[int] = mapped_column(ForeignKey('workspaces.id'))
    video_id: Mapped[int] = mapped_column(ForeignKey('videos.id'))
    kind: Mapped[str] = mapped_column(String(40))
    status: Mapped[str] = mapped_column(String(30),default='queued')
    attempts: Mapped[int] = mapped_column(Integer,default=0)
    error: Mapped[str] = mapped_column(Text,default='')
class Asset(Base):
    __tablename__='assets'
    id: Mapped[int] = mapped_column(primary_key=True)
    workspace_id: Mapped[int] = mapped_column(ForeignKey('workspaces.id'))
    video_id: Mapped[int] = mapped_column(ForeignKey('videos.id'))
    file_path: Mapped[str] = mapped_column(Text)
    license: Mapped[str] = mapped_column(String(80))
    proof: Mapped[str] = mapped_column(Text)
class Publication(Base):
    __tablename__='publications'
    id: Mapped[int] = mapped_column(primary_key=True)
    workspace_id: Mapped[int] = mapped_column(ForeignKey('workspaces.id'))
    video_id: Mapped[int] = mapped_column(ForeignKey('videos.id'),unique=True)
    platform_video_id: Mapped[str] = mapped_column(String(100),default='')
    status: Mapped[str] = mapped_column(String(30),default='pending')
class Metric(Base):
    __tablename__='metrics'
    id: Mapped[int] = mapped_column(primary_key=True)
    workspace_id: Mapped[int] = mapped_column(ForeignKey('workspaces.id'))
    publication_id: Mapped[int] = mapped_column(ForeignKey('publications.id'))
    views: Mapped[int] = mapped_column(Integer,default=0)
    likes: Mapped[int] = mapped_column(Integer,default=0)
    collected_at: Mapped[datetime] = mapped_column(DateTime(timezone=True),default=utcnow)
